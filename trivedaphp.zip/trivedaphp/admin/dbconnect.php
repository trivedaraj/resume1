<?php

	$link=mysqli_connect("localhost","root","","sanjana") or die("Error: connecting database.".mysqli_connect_error());

?>